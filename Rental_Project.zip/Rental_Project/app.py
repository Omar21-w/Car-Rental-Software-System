from flask import Flask, render_template, request, redirect, url_for, session, flash
from models import Car, Discount, Rental, Payment

app = Flask(__name__)
# Required for using the session
app.secret_key = 'a_very_secret_key_for_session'

# --- Main Page (lists available cars) ---
@app.route("/")
def index():
    cars = Car.get_all()
    return render_template('index.html', cars=cars)

# --- Step 1: Show Car Rental Form ---
@app.route("/rent/<car_id>", methods=['GET'])
def rent_car(car_id):
    car = Car.get_by_id(car_id)
    if not car or car['availability_status'] != "Available":
        flash("The car is not available or does not exist.", "danger")
        return redirect(url_for('index'))
    return render_template('rent_car.html', car=car)

# --- Step 2: Process Rental Form and Redirect to Discount ---
@app.route("/rent/process", methods=['POST'])
def process_rental():
    car_id = request.form.get('car_id')
    period = int(request.form.get('period'))
    start_date = request.form.get('start_date')
    car = Car.get_by_id(car_id)
    
    if not car:
        flash("Error in car data.", "danger")
        return redirect(url_for('index'))

    # Calculate initial price and store process data in the session
    total_price = car['rate_per_day'] * period
    session['rental_data'] = {
        'car_id': car_id,
        'period': period,
        'start_date': start_date,
        'total_price': total_price
    }
    
    return redirect(url_for('apply_discount_page'))

# --- Step 3: Apply Discount (Optional) ---
@app.route("/apply-discount", methods=['GET', 'POST'])
def apply_discount_page():
    rental_data = session.get('rental_data')
    if not rental_data:
        return redirect(url_for('index'))

    if request.method == 'POST':
        discount_code = request.form.get('discount_code')
        discount = Discount.find_by_code(discount_code)
        
        if discount:
            # Apply discount and update price in the session
            discounted_price = rental_data['total_price'] * (1 - discount['percentage'] / 100)
            session['rental_data']['total_price'] = discounted_price
            flash(f'Discount applied successfully! New price: ${discounted_price:.2f}', 'success')
        else:
            flash('Discount code is invalid or expired.', 'warning')
        
        return redirect(url_for('payment_page'))

    # GET request: show discount page with the current price
    return render_template('apply_discount.html', total_price=rental_data['total_price'])

# --- Step 4: Show Payment Page ---
@app.route("/payment", methods=['GET'])
def payment_page():
    rental_data = session.get('rental_data')
    if not rental_data:
        return redirect(url_for('index'))
    return render_template('payment.html', rental_data=rental_data)

# --- Step 5: Confirm Payment and Finalize ---
@app.route("/payment/confirm", methods=['POST'])
def payment_confirm():
    rental_data = session.get('rental_data')
    if not rental_data:
        flash('Session expired, please try booking again.', 'danger')
        return redirect(url_for('index'))
        
    payment_method = request.form.get('payment_method')
    
    # 1. Create a new rental record
    customer_id = "CUST-001" # Fixed customer ID for simplicity
    rental = Rental(
        customer_id, 
        rental_data['car_id'], 
        rental_data['start_date'], 
        rental_data['period'], 
        rental_data['total_price']
    )
    rental_id = rental.save()
    
    # 2. Create a new payment record
    payment = Payment(rental_id, rental_data['total_price'], payment_method)
    payment.save()
    
    # 3. Update car and rental status
    Rental.update_status(rental_id, "Completed")
    Car.update_status(rental_data['car_id'], "Rented")
    
    # 4. Clear session data
    session.pop('rental_data', None)
    
    flash('Payment and booking completed successfully!', 'success')
    return redirect(url_for('rental_success'))

@app.route("/rental/success")
def rental_success():
    return render_template('success.html')

if __name__ == '__main__':
    app.run(debug=True)
