import json
import uuid
from datetime import datetime

# --- Helper Functions for JSON Data ---
def load_data(filename):
    """Loads data from a JSON file in the data directory."""
    try:
        with open(f'data/{filename}', 'r', encoding='utf-8') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []

def save_data(filename, data):
    """Saves data to a JSON file in the data directory."""
    with open(f'data/{filename}', 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

# --- Models ---
class Car:
    @staticmethod
    def get_all():
        return load_data('cars.json')

    @staticmethod
    def get_by_id(car_id):
        cars = Car.get_all()
        for car in cars:
            if car['car_id'] == car_id:
                return car
        return None

    @staticmethod
    def update_status(car_id, new_status):
        cars = Car.get_all()
        for car in cars:
            if car['car_id'] == car_id:
                car['availability_status'] = new_status
                save_data('cars.json', cars)
                return True
        return False

class Discount:
    @staticmethod
    def get_all():
        return load_data('discounts.json')

    @staticmethod
    def find_by_code(code):
        discounts = Discount.get_all()
        for discount in discounts:
            if discount['code'] == code:
                return discount
        return None

class Rental:
    def __init__(self, customer_id, car_id, start_date, period, total_price, status="Pending"):
        self.rental_id = str(uuid.uuid4())[:8]
        self.customer_id = customer_id
        self.car_id = car_id
        self.start_date = start_date
        self.period = period
        self.total_price = total_price
        self.status = status

    def save(self):
        rentals = load_data('rentals.json')
        rentals.append(self.__dict__)
        save_data('rentals.json', rentals)
        return self.rental_id

    @staticmethod
    def get_by_id(rental_id):
        rentals = load_data('rentals.json')
        for rental in rentals:
            if rental['rental_id'] == rental_id:
                return rental
        return None

    @staticmethod
    def update_status(rental_id, new_status):
        rentals = load_data('rentals.json')
        for rental in rentals:
            if rental['rental_id'] == rental_id:
                rental['status'] = new_status
                save_data('rentals.json', rentals)
                return True
        return False

class Payment:
    def __init__(self, rental_id, amount, payment_method):
        self.payment_id = str(uuid.uuid4())[:8]
        self.rental_id = rental_id
        self.amount = amount
        self.payment_method = payment_method
        self.status = "Paid"
        self.date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def save(self):
        payments = load_data('payments.json')
        payments.append(self.__dict__)
        save_data('payments.json', payments)
